﻿namespace PayRollTaxCalculator
{


    partial class TaxUsersDataSet
    {
    }

}
